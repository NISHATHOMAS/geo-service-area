class ServiceAreaSerializer:
    pass
