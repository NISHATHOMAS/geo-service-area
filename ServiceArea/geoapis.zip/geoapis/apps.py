from django.apps import AppConfig


class GeoapisConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'geoapis'
